import 'dotenv/config';
import { createServer } from 'http';
import { loadFullConfig } from './agent/skills-config.js';
import { config } from './config.js';
import { initDb, log } from './db/index.js';
import { createGateway, attachWebSocket } from './gateway/server.js';
import { startWatcher, setEventCallback, enqueueTaskOnEvent } from './watcher/index.js';
import { setTaskHandler, loadPendingFromDb, enqueue } from './scheduler/queue.js';
import { scheduleCron } from './scheduler/cron.js';
import { loadAllPlugins, onFileEvent, onTask } from './plugins/index.js';
import { fireWebhooks } from './webhooks.js';
import { registerBuiltInTools } from './agent/tools.js';
import { startSkillsWatcher } from './agent/skills-watcher.js';
import type { AppLocals } from './types.js';

async function main(): Promise<void> {
  initDb(config.dbPath);
  // Inject skill config into process.env so run_command (e.g. curl with $PERIGON_API_KEY) sees them
  const full = loadFullConfig();
  const entries = full.skills?.entries;
  if (entries && typeof entries === 'object') {
    for (const entry of Object.values(entries)) {
      if (!entry || typeof entry !== 'object') continue;
      for (const [key, value] of Object.entries(entry)) {
        if (key === 'enabled') continue;
        if (typeof value === 'string' && value.trim() && !process.env[key]) process.env[key] = value;
      }
    }
  }
  log('main', 'info', 'Starting Sulala Agent', { port: config.port });

  registerBuiltInTools(enqueue);

  const app = createGateway();
  (app.locals as AppLocals).enqueueTaskId = enqueue;
  const http = createServer(app);
  const { broadcast } = attachWebSocket(http);
  (app.locals as AppLocals).wsBroadcast = broadcast;
  const server = http.listen(config.port, config.host, () => {
    console.log(`Gateway http://${config.host}:${config.port} (WS /ws)`);
  });
  const shutdown = () => {
    log('main', 'info', 'Shutting down');
    server.close(() => {
      log('main', 'info', 'Gateway closed');
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000);
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  await loadAllPlugins();

  setEventCallback((payload) => {
    onFileEvent(payload);
    enqueueTaskOnEvent(payload);
    broadcast({ type: 'file_event', payload });
    fireWebhooks('file_event', payload);
  });
  startWatcher();
  startSkillsWatcher(config, (ev) => broadcast(ev));

  setTaskHandler(async (task) => {
    const handled = await onTask(task);
    if (handled) return;
    if (task.type === 'file_event') {
      log('worker', 'info', 'File event task', (task.payload ?? null) as Record<string, unknown> | null);
    }
    broadcast({ type: 'task_done', taskId: task.id });
    fireWebhooks('task_done', { taskId: task.id, type: task.type });
  });

  loadPendingFromDb();
  scheduleCron('* * * * *', 'heartbeat', { ts: Date.now() });

  log('main', 'info', 'Sulala Agent ready');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
