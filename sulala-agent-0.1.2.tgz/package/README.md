# Sulala Agent — Local AI Orchestration Platform

A local-first platform that combines **file monitoring**, **task scheduling**, **AI orchestration**, and a **plugin system**. Runs on `127.0.0.1` and stays on your machine.

## Architecture (high level)

| Layer | Role |
|-------|------|
| **Gateway** | REST + WebSocket API on `localhost:3000`; auth and request handling |
| **File watcher** | Real-time folder watch (add/change/delete) → event triggers |
| **Task scheduler** | Cron-like scheduling + queue with retries and failure handling |
| **AI orchestration** | Single interface to multiple providers (OpenAI, OpenRouter, Claude, Gemini, Ollama); routing and rate limits |
| **Plugins** | Scripts and integrations that hook into events, tasks, and AI |
| **Persistence** | SQLite for tasks, file state, logs, and AI results |

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and the project diagram for full layout.

## Quick start

```bash
# Install dependencies
npm install

# Configure (copy and edit)
cp .env.example .env

# Run gateway + watcher + scheduler (TypeScript via tsx)
npm start
```

**Development:** `npm run dev` runs the app with `tsx watch` (restarts on file changes). For a production build: `npm run build` then `node dist/index.js` (or run the gateway with `node dist/gateway/server.js`). Run tests with `npm test` and lint with `npm run lint`.

**Dashboard (React + Vite + shadcn/ui):**

- **Dev:** run the UI on its own port (e.g. 5173) while the gateway runs on 3000:
  ```bash
  npm run dashboard
  ```
  Then open the URL Vite prints (e.g. http://localhost:5173). Set `VITE_GATEWAY_URL=http://127.0.0.1:3000` in `dashboard/.env` if the API is on another host.
- **Production:** build and serve from the gateway (one origin):
  ```bash
  npm run dashboard:build
  npm start
  ```
  Then open http://127.0.0.1:3000 — the gateway serves the built dashboard and the API.

**CLI** (from project root):

```bash
# Via npm script
npm run cli -- status
npm run cli -- tasks --limit=20
npm run cli -- logs --limit=50
npm run cli -- enqueue --type=heartbeat --payload='{"x":1}'

# Or install globally: npm link (from project root)
sulala status
sulala tasks --limit=20
sulala skill list
sulala skill install apple-notes [--global]
sulala skill update
sulala skill uninstall apple-notes [--global]
```

**Skill commands:** `sulala skill list` lists registry skills. `sulala skill install <slug> [--global]` installs to workspace (default) or managed dir (`~/.sulala/skills`). `sulala skill update` refreshes installed skills from the registry. `sulala skill uninstall <slug> [--global]`. `sulala init [dir]` creates config/context/registry and copies `.env.example` → `.env` in a directory.

**Onboard & daemon (global install):** After `npm i -g @sulala/agent`, run `sulala onboard` to create `~/.sulala` and a default `.env`; your browser opens to **http://127.0.0.1:3000/onboard** where you can add API keys (saved to `~/.sulala/.env`). Then `sulala onboard --install-daemon` to install a background service (launchd on macOS, systemd on Linux) so the agent runs at login; the browser opens again after the daemon starts. Logs: `~/.sulala/logs/`. To remove: `sulala onboard --uninstall-daemon`.

Set `GATEWAY_URL` and optionally `GATEWAY_API_KEY` when using gateway commands. Set `SULALA_SKILLS_DIR` and `AGENT_CONTEXT_PATH` for skill paths.

**Agent runner:** Multi-turn sessions with optional tool use. Create a session, then send messages to run the agent loop (model can call tools; built-in `run_task` enqueues background tasks). See [docs/ROADMAP_AGENT_RUNNER.md](docs/ROADMAP_AGENT_RUNNER.md) and [docs/AGENT_API.md](docs/AGENT_API.md).
- `GET /api/agent/sessions` — list sessions (query: `limit`).
- `POST /api/agent/sessions` — create or get session (body: `{ "session_key": "my-chat", "meta": {} }`).
- `GET /api/agent/sessions/:id` — get session and message history.
- `POST /api/agent/sessions/:id/messages` — send a message and run the agent turn (body: `{ "message": "…", "system_prompt": "…", "provider": "openai", "timeout_ms": 300000 }`). Returns `{ finalContent, messages, turnCount }`. Runs are serialized per session; client disconnect or timeout aborts the run (`AGENT_TIMEOUT_MS` in env or `timeout_ms` in body).

**AI models:** Supported providers: OpenAI (e.g. gpt-5.2, gpt-5-mini, gpt-4o-mini), OpenRouter (one key for many models, e.g. openai/gpt-5.2, anthropic/claude-sonnet-4), Claude (Opus 4.6, Sonnet 4.6, Haiku 4.5), Gemini (2.5 Flash/Pro, 3.1 Pro), Ollama (local). See [docs/MODELS.md](docs/MODELS.md) for model IDs and env vars (`AI_*_DEFAULT_MODEL`, `OPENROUTER_API_KEY`, `GOOGLE_GEMINI_API_KEY`).

**Config:** Watched folders can be set in `.env` (`WATCH_FOLDERS`) or in `config/watched.json` (array `folders`); both are merged. Optional gateway auth via `GATEWAY_API_KEY`; webhooks via `WEBHOOK_URL` or `WEBHOOK_URLS` and optional `WEBHOOK_SECRET`. AI: set `OPENAI_API_KEY`, `OPENROUTER_API_KEY`, `ANTHROPIC_API_KEY`, and/or use Ollama (`OLLAMA_BASE_URL`, default `http://localhost:11434`). Optional rate limit: `RATE_LIMIT_MAX`, `RATE_LIMIT_WINDOW_MS`. See `.env.example`.

**Docker:** Build and run with dashboard served from the gateway:
```bash
docker compose up --build
```
Then open http://localhost:3000. Mount `./config` for watched folders; data is stored in a named volume.

## Requirements

- **Node.js** 18+
- **TypeScript** + **tsx** (dev; in package.json)
- **Python 3.10+** (optional, for AI/automation scripts)
- SQLite (included via `better-sqlite3`)

## Project layout

Backend is TypeScript (`src/**/*.ts`); runs with `tsx` or compile with `tsc` to `dist/`.

```
sulala_agent/
├── src/
│   ├── gateway/      # API server (REST/WS), auth
│   ├── watcher/      # File/folder watcher (chokidar)
│   ├── scheduler/    # Cron + task queue
│   ├── ai/           # AI orchestration (multi-provider)
│   ├── plugins/      # Plugin loader and hooks
│   └── db/           # SQLite schema and access
├── scripts/          # User and plugin automation (Python/Node/Bash)
├── config/           # Watched folders, cron rules, plugin config
├── docs/
└── dashboard/        # Web UI (React + Vite + Tailwind + shadcn/ui)
```

## Security

- Services bind to `127.0.0.1` only (no internet exposure by default).
- Store API keys and secrets in `.env`; never commit them.
- Plugins and automation scripts can be sandboxed (e.g. run in subprocess with limited permissions).

## License

MIT
